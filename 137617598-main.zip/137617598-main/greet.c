#include <cs50.h>
#include <stdio.h>

int main( int argc, string argv[])
{
    printf("hello, %s\n", arvg[1]);
}
