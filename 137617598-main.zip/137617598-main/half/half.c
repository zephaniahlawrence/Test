// Calculate your half of a restaurant bill
// Data types, operations, type casting, return value

#include <cs50.h>
#include <stdio.h>



int main(void)
{
    float a = get_float("Bill before tax and tip?: \n");
    if (a < 0)
    {
        do
            a = get_int("Invalid value. Bill before tax and tip?: \n");
        while (a < 0);
    }



    float b = get_float("Sales Tax Percent?: \n");
    if (b < 0)
    {
        do
            b = get_int("Invalid value. Sales Tax Percent?: \n");
        while (b < 0);
    }



    int c = get_int("Tip percent?: \n");
    if (c < 0)
    {
        do
            c = get_int("Invalid value. Tip percent?: \n");
        while (c < 0);
    }



    float d = (a + (a * (b/100)) + ((a + (a * (b/100))) * c/100)) / 2;
    printf("You will owe $%.2f each!\n", d);
}
