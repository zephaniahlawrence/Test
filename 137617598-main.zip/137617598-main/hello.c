#include <cs50.h>
#include <stdio.h>

int main(void)
{
    string first = get_string("What's your first name? ");
    string last = get_string("What's your last name? ");
    printf("hello, %s %s!\n", first, last);
}
    if (x < y)
{
        printf("x is less than y\n");
}
    else if (x > y)
{
        printf("x is not less than y\n");
}
    else (x == y)
{

}







    int answer = get_int("What is 7 times 4? ");
    printf("Correct! The answer is %i!\n", answer);
}