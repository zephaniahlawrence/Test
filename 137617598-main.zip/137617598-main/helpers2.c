#include "helpers.h"

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    int b = 0;
    int g = 0;
    int r = 0;
    int avg = (b + g + r) / 3;

    for (int image[height] = 0; image[height] < image[height - 1]; height++)
    {
        for (int image[width] = 0; image[width] < image[width - 1]; width++)
        {
            b = image[height][width].rgbtblue++;
            g = image[height][width].rgbtgreen++;
            r = image[height][width].rgbtred++;

            break;
        }
    }
    return;

    for (int image[height] = 0; image[height] < image[height - 1]; height++)
    {
        for (int image[width] = 0; image[width] < image[width - 1]; width++)
        {
            image[height][width].rgbtblue = avg;
            image[height][width].rgbtgreen = avg;
            image[height][width].rgbtred = avg;
        }
    }
    return;

}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    return;
}

// Detect edges
void edges(int height, int width, RGBTRIPLE image[height][width])
{
    return;
}
