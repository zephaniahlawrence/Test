#include <stdio.h>
#include <cs50.h>

int main(void)
{
  int n = get_int("Starting population?: \n");
    if (n > 1)
    {
    if (n > 1)
    {
        int m = get_int("How many years have passed?: \n);
    }
    }
    else if (n < 1)
    {
    if (n < 1)
    do
    {
        n = get_int("Invalid Value. Starting population?: ");
    }
    while (n < 1);
    }
}