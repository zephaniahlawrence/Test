#include <stdio.h>
#include <cs50.h>

int main(void)
{
  int a = get_int("Starting population?: \n");
  int b = get_int("Invalid value. Starting population?: \n");
  int c = get_int("How many years have passed?: \n");
  int d = get_int("Invalid value. How many years have passed?: \n");
  int e = a||b + (a||b / 3) - (a||b / 4) * c||d;
        printf("Population remaining: %i\n", e);

    if (a > 1)
    {
            c = get_int("How many years have passed?: \n");
    }
    if (a < 1)
    do
    {
            b = get_int("Invalid value. Starting population?: ");
    }
    while (b < 1);


    if (c > 1)
    {
        e = printf("Population remaining: %i\n", d);
    }
    if (c < 1)
    do
    {
            d = get_int("Invalid value. How many years have passed?: \n");
    }
    while (d < 1);
}