#include <stdio.h>
#include <cs50.h>

int main(void)
{
  int a = get_int("Starting population?: \n");
  int b = get_int("How many years have passed?: \n");
  int c = a + ((a / 3) - (a / 4)) * b;
        printf("Population remaining: %i\n", c);

    if (a > 1)
    {
            b = get_int("How many years have passed?: \n");
    }
    else if (a < 1)
    {
            do
            a = get_int("Invalid value. Starting population?: \n");
            while (a < 1);
    }


    if (b > 1)
    {
        c = printf("Population remaining: %i\n", c);
    }
    else if (b < 1)
    {
            do
            b = get_int("Invalid value. How many years have passed?: \n");
            while (b < 1);
    }
}