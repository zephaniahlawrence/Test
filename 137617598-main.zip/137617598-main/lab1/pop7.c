#include <stdio.h>
#include <cs50.h>

int main(void)
{
    int a = get_int("Starting population?: \n");
    if (a < 1)
    do
    {
        a = get_int("Invalid value. Starting population?: \n");
    }
    while (a < 1);


    int b = get_int("How many years have passed?: \n");
    if (b < 1)
    do
    {
        b = get_int("Invalid value. How many years have passed?: \n");
    }
    while (b < 1);


    if (a >= 1)
    do
    {

        b = get_int("How many years have passed?: \n");
    }
    while (a >= 1);


    int c = a + ((a / 3) - (a / 4)) * b;
    if (b >= 1)
    {
        c = printf("Population remaining: %i\n", c);
    }
}