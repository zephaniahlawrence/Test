#include <stdio.h>
#include <cs50.h>

int main(void)
{
    int a = get_int("Starting population?: \n");
    if (a < 1)
    {
        do
            a = get_int("Invalid value. Starting population?: \n");
        while (a < 1);
    }


    int b = get_int("How many years have passed?: \n");
    if (b < 1)
    {
        do
            b = get_int("Invalid value. How many years have passed?: \n");
        while (b < 1);
    }


// Processes & generates results
    int c = a + ((a / 3) - (a / 4)) * b;
    if (b >= 1)
    {
        a = printf("Starting population: %i\n", a);
        c = printf("Population remaining: %i\n", c);
        b = printf("Years passed: %i\n", b);
    }
}




20 + ((7)-(5))
22 * 20







    int c = 0;
    do
    {
        b = (a * ((1 + ((.08/100)*(.08/100)) * c)));
        b = (a * (
    }
    while (c > 1);
    return c;

---------------------------------------------------

    for (int c = 0; c < ; c++)
    {
        for (int j = 0; j < n; j++)
        {
            get_int("#");
        }
        get_int();
