#include <stdio.h>
#include <cs50.h>

int main(void)
{
  int n = get_int("Starting population?: \n");
       int n;
    do
    {
        n = get_int("Invalid Value. Starting population?: ");
    }
    while (n < 1);
}


      if (n < 1)
    {
        n = get_int("Invalid Value. Starting population?: ");
    }