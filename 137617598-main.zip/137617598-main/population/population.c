#include <cs50.h>
#include <stdio.h>

int main(void)
{
    // TODO: Prompt for start size

    int a = get_int("Starting EOYV?: \n");
    if (a < 9)
    {
        do
            a = get_int("Invalid value. Starting EOYV?: \n");
        while (a < 9);
    }

    // TODO: Prompt for end size

    int b = get_int("What is the EOYV?: \n");
    if (b < a)
    {
        do
            b = get_int("Invalid value. What is the EOYV?: \n");
        while (b < a);
    }

    // TODO: Calculate number of years until threshold is reached

    int c = 0;
    while (a < b)
    {
        a = a + ((a / 3) - (a / 4));
        c++;
    }

    // TODO: Print number of years
    c = printf("Years passsed: %i\n", c);
}
