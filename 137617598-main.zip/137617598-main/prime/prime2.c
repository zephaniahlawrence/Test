#include <cs50.h>
#include <stdio.h>

int main(void)
{

    int min;
    do
    {
        min = get_int("What is the minimum value?: \n");
    }
    while (min < 1);

    int max;
    do
    {
        max = get_int("What is the maximum value?: \n");
    }
    while (min >= max);

    for (int r = min; r <= max; r++)
    {
        if
    }

}

bool prime(int number)




        else if (r == 1)
        return false;
