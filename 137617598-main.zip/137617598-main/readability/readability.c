#include <cs50.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

int nop(string txt);
int noc(string txt);
int noe(string txt);

int main(void)
{
    string input = get_string("Input: ");

    int now = noe(input);
    int nos = nop(input);
    int nol = noc(input);

    float L = ((float) nol) / ((float) now) * 100;
    float S = ((float) nos) / ((float) now) * 100;
    float preindex = 0.0588 * L - 0.296 * S - 15.8;
    int index = round(preindex);

    if (index >= 1 && index <= 15)
    {
        printf("Grade %i\n", index);
    }
    else if (index < 1)
    {
        printf("Before Grade 1\n");
    }
    else
    {
        printf("Grade 16+\n");
    }
}

int noe(string txt)
{
    int noe = 0;

    for (int e = 0, s = strlen(txt); e < s; e++)
    {
        if (isspace(txt[e]))
        {
            noe += 1;
        }
    }
    return noe + 1;
}

int nop(string txt)
{
    int nop = 0;

    for (int p = 0, s = strlen(txt); p < s; p++)
    {
        if (txt[p] == '.' || txt[p] == '!' || txt[p] == '?')
        {
            nop += 1;
        }
    }
    return nop;
}

int noc(string txt)
{
    int noc = 0;

    for (int c = 0, s = strlen(txt); c < s; c++)
    {
        if (isalpha(txt[c]))
        {
            noc += 1;
        }
    }
    return noc;
}
