#include <cs50.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

string k = get_string("Key: \n");
string keymap[] = {k[0], k[1], k[2], k[3], k[4], k[5], k[6], k[7], k[8], k[9], k[10], k[11],k[12], k[13], k[14], k[15], k[16], k[17], k[18], k[19], k[20], k[21], k[22], k[23], k[24], k[25]};

int main(void)
{

    string key[26] = get_int("Key: \n");
    printf("Encrypted Return: %s\n", encryption(key));

    string usrinput = get_string("Input Value: \n");
    printf("Encryption Return: \n");
    for (int c = 0; c < strlen(usrinput); c++)
    {
        printf("%c", usrinput[c] + 4);
    }
    printf("\n");


string encryption(string input)
{
    string
}

    int rtn = 0;

    for (int c = 0; c < strlen(input); c++)
    {
        if(isalnum(input[c]) || ispunct(input[c]))
        {
            rtn = input[c] + 7;
        }
    }
    return rtn;


        {
        rtn = kaymap[input[c]];
        }




    string k[25] = get_int("Key: \n");
    k[0]
    k[1]
    k[2]
    k[3]
    k[4]
    k[5]
    k[6]
    k[7]
    k[8]
    k[9]
    k[10]
    k[11]
    k[12]
    k[13]
    k[14]
    k[15]
    k[16]
    k[17]
    k[18]
    k[19]
    k[20]
    k[21]
    k[22]
    k[23]
    k[24]
    k[25]




    string encryption(string input)
{

    int rtn = c;

    for (int c = 0; c < strlen(input); c++)
    {
        if(isalnum(input[c]) || ispunct(input[c]))
        {
            rtn = keymap[input[c]];
        }
    }
    return rtn;
}


    for (int c = 0; c < strlen(usrinput); c++)
    {
        printf("Encryption Return: %c\n", keymap[usrinput[c]]);
    }
}
