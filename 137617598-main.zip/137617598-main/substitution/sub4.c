#include <cs50.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <string.h>


string encryption(string input);





int main(void)
{

    string usrinput = get_string("Input Value: \n");

    string k = get_string("Key: \n");

    string keymap[] = {k[0], k[1], k[2], k[3]};

k[0] = get_string("Key: \n");



    for (int c = 0; c < strlen(usrinput); c++)
    {
        if (encryption(usrinput))
        {
            printf("Encryption Return: %c\n", usrinput[c]);
        }
    }
}






string encryption(string input)
{

    string rtn = 0;

    for (int c = 0; c < strlen(input); c++)
    {
        if(isalnum(input[c]) || ispunct(input[c]))
        {
            rtn = keymap[input[c]];
        }
    }
    return rtn;
}











SUB55555555


int main(int keyc, string key[]);
{
    if (keyc != 4)
    {
        printf("Error: Key must contain 4 characters.\n");
    }
    else
    {
        string usrinput = get_string("Input Value: \n");

        for (int c = 0; c < strlen(usrinput); c++)
        {
            if (encryption(usrinput))
            {
                printf("Encryption Return: %s\n", usrinput);
            }
        }
    }

}



string keymap[] = {key[1]};
string encryption(string input)
{
    for (int c = 0; c < strlen(input); c++)
    {
        if(isalnum(input[c]))
        {
            keymap[input[c]];
        }
        return true;
    }
}






for (int k = 0; k < strlen(keyn); k++)
