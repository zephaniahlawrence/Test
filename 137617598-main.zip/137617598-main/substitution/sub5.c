#include <cs50.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

int main(int keyc, string keyn[])
{

    int cc = 0;

    for (int k = 0; k < keyc; k++)
    {
        cc += 1;
    }
    return cc;


    if (cc != 4)
    {
        printf("Error: Key must contain 4 characters.\n");
        return 1;
    }
    else
    {
        string usrinput = get_string("Input Value: \n");
        return 0;
    }
}












int countkey(string key);

int main(void)
{
    string keyinput = get_string("Key: ");
    int keyc = countkey(keyinput);
    if (keyc != 4)
    {
        do
            keyinput = get_string("Error: Key must contain 4 characters.\nKey: ");
        while (keyc != 4);
    }
    else
    {
        string usrinput = get_string("Input Value: \n");
    }
}


int countkey(string key)
{
    int count = 0;

    for (int k = 0; k < strlen(key); k++)
    {
        if (isalpha(key[k]))
        {
        count += 1;
        }
    }
    return count + 1;
}


    string keymap[keyinput[c]];
    for (int c = 0, c < strlen(keyinput); c++)
    {
        keymap = {keyinput[c]};
    }
    return keymap;






    int keyc = 0;

    for (int k = 0; k < strlen(keyinput); k++)
    {
            keyc = keyc + 1;
    }
    return keyc;



    for (int c = 0, c < strlen(keyinput); c++)
    {
        keymap = {keyinput[c]};
    }
    return keymap;






string encrypt(string txt)
{
    int rtn = 0;

    for (int c = 0, c < strlen(txt); c++)
    {
        rtn += keymap[txt[c]];
    }
    return rtn;
}






string encrypt(string txt)
{
    for (int c = 0, c < strlen(txt); c++)
    {
        if (isalpha(txt[c]))
        {
            keymap[txt[c]];
        }
    }
    return true;
}




string encrypt(string txt)
{
    int rtn = 0;
    for (int c = 0; c < strlen(txt); c++)
    {
        rtn = keymap[txt[c]];
    }
    return rtn;
}
