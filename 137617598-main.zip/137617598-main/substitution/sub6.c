#include <cs50.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <string.h>



int main(void)
{

    string key = get_string("Key: ");
    if (strlen(key) != 4)
    {
        do
            key = get_string("Error: Key must contain 4 characters.\nKey: ");
        while (strlen(key) != 4);
    }

    string usrinput = get_string("Input Value: ");

    string keymap[] = {key};


    printf("Return Value: ");
    for (int c = 0, n = strlen(c)); c < n; c++)
    {
        printf("%c", keymap[key[c]]);
    }

}

bria is so hot omg



string keymap[] = {N,Q,X,P,O,M,A,F,T,R,H,L,Z,G,E,C,Y,J,I,U,W,S,K,D,V,B};





    int k = 0;
    while (key[k] != '\0')
    {
        k++;
    }

    if (k != 4)
    {
        printf("Error: Key must contain 4 characters.\n");
    }
    else
    {
        string usrinput = get_string("Input Value: ");
    }





#include <cs50.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

int encrypt(string usrinput);

int main(int keyc, string key[])
{
    string keymap[] = {key};

    if (key[1] == 0 || strlen(key[1]) != 4)
    {
        printf("Error: Key must contain 4 characters.\n");
    }
    else
    {
        string usrinput = get_string("Input Value: ");
    }

    for (int c = 0; c < strlen(key[1]); c++)
    {
        printf("Return Value: %c", encrypt(key[1]));
    }
}

int encrypt(string usrinput)
{

}
















#include <cs50.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

int encrypt(string ui);

int main(int keyc, string key[])
{
    string keymap[] = {key[1]};



    if (keyc != 1 || strlen(key[1]) != 4)
    {
        printf("Error: Key must contain 4 characters.\n");
    }

    string ui = get_string("Input Value: ");


    printf("Return Value: %c", encrypt(ui));
}



bool encrypt(string ui)
{
    for (int c = 0; c < strlen(ui); c++)
    {
        if (isalpha(uc[c]))
        {
            keymap[ui[c]];
        }
    }
    return true;
}


string encrypt(string ui)
{
    for (int c = 0; c < strlen(ui); c++)
    {
            keymap[ui[c]];
    }

}












    for (int c = 0, sl = strlen(key[1]); c < sl; c++)

    else if (k1[c] != isalpha(k1[c]))
    {
        printf("Error: Key must consist of only alphabetical characters.\n");
    }










    if (keyc != 2 || strlen(key[1]) != 4)
    {
        printf("Error: Key must contain 4 characters.\n");

    if (keyc == 2 && strlen(key[1]) == 4)

        for (int c = 0, sl = strlen(key[1]); c < sl; c++)
        if (ispunct(c) || isspace(c) || isdigit(c))
        {
            printf("Error: Key must consist of only alphabetical characters.\n");
        }
        else
        {
            string ui = get_string("Input Value: ");
            printf("Return Value: \n");
        }
    }















    if (keyc != 2 || strlen(key[1]) != 4)
    {
        printf("Error: Key must contain 4 characters.\n");
    }

    else if (keyc == 2 && strlen(key[1]) == 4)
    {
        for (int c = 0, sl = strlen(key[1]); c < sl; c++)
        if (ispunct(c) || isspace(c) || isdigit(c))
        {
            printf("Error: Key must consist of only alphabetical characters.\n");
        }
        else
        {
            string ui = get_string("Input Value: ");
            printf("Return Value: \n");
        }
    }








    int nc = 0;
    for (int c = 0, sl = strlen(key); c < sl; c++)
    {
        nc = key[c];
        nc = (key[c] - key[c]) +
    }
    return nc;







    int keycheck2(string key)
{
    int cc = 0;
    for (int c = 0, sl = strlen(key); c < sl; c++)
    {
        cc += toascii(tolower(key[c]));
    }
    return cc;
}

int encrypt(string key)
{
    int nc = 0;
    for (int c = 0, sl = strlen(key); c < sl; c++)
    {
        nc = tolower(key[c]);
    }
    return nc;

}






int keycheck2(string key)
{
    int cc = 0;
    for (int c = 0, sl = strlen(key); c < sl; c++)
    {
        cc += toascii(tolower(key[c]));
    }
    return cc;
}














    else
    {
        string ui = get_string("Input Value: ");
        printf("Return Value: \n");
    }
}

int keycheck(string key)
{
    int ic = 0;
    for (int c = 0, sl = strlen(key); c < sl; c++)
    {
        if (ispunct(c) || isspace(c) || isdigit(key[c]))
        {
            ic += 1;
        }
    }
    return ic;
}

int keycheck2(string key)
{
    int cc = 0;
    for (int c = 0, sl = strlen(key); c < sl; c++)
    {
        cc += toascii(tolower(key[c]));
    }
    return cc;
}








    string keymap = key[1];
    for (int i = 0; i < strlen(keymap); i++)








    else
    {
        string ui = get_string("Input Value: ");
        string keymap = key[1];
        int i = 0;
        while (keymap[i] != '\0')
        {
            i++;
        }

        if (encrypt(keymap, ui))
        printf("Return Value: \n");
        printf("%c\n", encrypt(keymap, ui));
    }





















    bool encrypt(string key, string ui)
{
    int nc = 0;

    for (int c = 0; c < strlen(key); c++)
    for (int r = c + 1; r < strlen(ui); r++)
    {
        if (isupper(key[c]))
        {
            int fv = key[c] - 65;
            nc = fv + ui[r];
        }
        else if (islower(key[c]))
        {
            int fv2 = toupper(key[c]) - 97;
            nc = fv2 + ui[r];
        }
    }
    return true;
}








    else
    {
        string ui = get_string("Input Value: ");
        string keymap = key[1];
        for (int i = 0; i < strlen(keymap); i++)
        {
            if (encrypt(keymap, ui))
            {
                printf("Return Value: %i\n", encrypt(keymap, ui));
            }
        }
    }
