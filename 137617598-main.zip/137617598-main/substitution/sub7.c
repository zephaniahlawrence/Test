#include <cs50.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

int keycheck(string key);
int encrypt(char ui, char keymap);

int main(int keyc, string key[])
{
    if (keyc != 2 || strlen(key[1]) != 26)
    {
        printf("Error: Key must contain 4 characters.\n");
    }
    else if (keycheck(key[1]) == 1)
    {
        printf("Error: Key must consist of only alphabetical characters.\n");
    }
    else if (keycheck(key[1]) == 2)
    {
        printf("Error: Key must consist of 26 unique alphabetical characters.\n");
    }
    else
    {
        string ui = get_string("Input Value: ");
        string keymap = key[1];
        printf("Return Value: ");
        for (int c = 0; c < strlen(ui); c++)
        for (int r = 0; r < strlen(keymap); r++)
        {
                int ic = ui[c] - 97;
                int rc = keymap[ic];
                printf("%c ", rc);
        }
        printf("\n");
    }
}

int keycheck(string key)
{
    int ic = 0;

    for (int c = 0, kl = strlen(key); c < kl; c++)
    {
        if (ispunct(key[c]) || isspace(key[c]) || isdigit(key[c]))
        {
            ic = 1;
            return ic;
        }
        else if (ic == 0)
        {
            key[c] = toupper(key[c]);
            for (int kc = c + 1; kc < kl; kc++)
            if (key[c] == key[kc])
            {
                ic = 2;
                return ic;
            }
        }
    }
    return ic;
}

int encrypt(char ui, char keymap)
{
    int r = 0

    for (int c = 0; c < strlen(ui); c++)
    for (int r = 0; r < strlen(keymap); r++)
    {
        int ic = ui[c] - 97;
        int rc = keymap[ic];

    }
    return r;
}
