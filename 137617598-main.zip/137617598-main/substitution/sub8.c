#include <cs50.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

int keycheck(string key);
int encrypt(int ui, string keymap);

int main(int keyc, string key[])
{
    if (keyc != 2 || strlen(key[1]) != 26)
    {
        printf("Error: Key must contain 26 characters.\n");
        return 1;
    }
    else if (keycheck(key[1]) == 1)
    {
        printf("Error: Key must consist of only alphabetical characters.\n");
        return 1;
    }
    else if (keycheck(key[1]) == 2)
    {
        printf("Error: Key must consist of 26 unique alphabetical characters.\n");
        return 1;
    }
    else
    {
        string ui = get_string("Initial Value: ");
        string keymap = key[1];
        printf("Return Value: ");      
        for (int c = 0; c < strlen(ui); c++)
        {
            printf("%c", encrypt(ui[c], keymap));
        }
        printf("\n");
        return 0;
    }
}

int keycheck(string key)
{
    int ic = 0;

    for (int c = 0, kl = strlen(key); c < kl; c++)
    {
        if (ispunct(key[c]) || isspace(key[c]) || isdigit(key[c]))
        {
            ic = 1;
            return ic;
        }
        else if (ic == 0)
        {
            key[c] = toupper(key[c]);
            for (int kc = c + 1; kc < kl; kc++)
            if (key[c] == key[kc])
            {
                ic = 2;
                return ic;
            }
        }
    }
    return ic;
}

int encrypt(int ui, string keymap)
{
    int rc = 0;
    for (int r = 0; r < strlen(keymap); r++)
    {
        if (islower(ui) && isupper(keymap[r]))
        {
            int ic = ui - 97;
            rc = tolower(keymap[ic]);
        }
        else if (islower(ui) && isupper(keymap[r]))
        {
            int ic = ui - 97;
            rc = keymap[ic];
        }
        else if (isupper(ui) && islower(keymap[r]))
        {
            int ic = ui - 65;
            rc = toupper(keymap[ic]);
        }
        else if (isupper(ui) && isupper(keymap[r]))
        {
            int ic = ui - 65;
            rc = keymap[ic];
        }
        else if (ispunct(ui))
        {
            rc = 'x';
        }
        else if (isspace(ui))
        {
            rc = ui;
        }
        else if (isdigit(ui))
        {
            rc = '0';
        }
    }
    return rc;
}
